import scala.io.Source
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import java.util.Properties

object KafkaProducerApp extends App{

  /** Properties for Kafka Client */
  val props: Properties = new Properties()
  props.put("bootstrap.servers", "localhost:9092")
  props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
  props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")
  props.put("acks", "all")

  /** Kafka Client Producer */
  val producer = new KafkaProducer[String, String](props)

  /** Local file paths */
  val fileLocationsPath = "src/main/data/locations.json"
  val fileTransactionPath = "src/main/data/transactions.json"

  /** Kafka Topic & Key Values */
  val kafkaTopic = "channel"
  val trxKey = "transactions"
  val locKey = "locations"

  /** Push Transactions Data into Kafka Topic */
  for (trx <- Source.fromFile(fileTransactionPath).getLines) {
    producer.send(new ProducerRecord(kafkaTopic, trxKey, trx))
  }
  /** Push Locations Data into Kafka Topic */
  for (loc <- Source.fromFile(fileLocationsPath).getLines) {
    producer.send(new ProducerRecord(kafkaTopic, locKey, loc))
  }

  /** Close Connection to Kafka Broker */
  producer.close()

}