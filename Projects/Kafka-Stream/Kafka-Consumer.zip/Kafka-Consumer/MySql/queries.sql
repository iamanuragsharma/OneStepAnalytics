-- Check all Database list
show databases;

-- Create Database streamdb
create database streamdb;

-- Create Table Transactions DDL
CREATE TABLE IF NOT EXISTS streamdb.transactions (
  UniqueId               VARCHAR(128),
  TransactionDateUTC     VARCHAR(64),
  Itinerary              VARCHAR(64),
  OriginAirportCode      VARCHAR(4),
  DestinationAirportCode VARCHAR(4),
  OneWayOrReturn         VARCHAR(10),
  DepartureAirportCode   VARCHAR(4),
  ArrivalAirportCode     VARCHAR(4),
  SegmentNumber          INT,
  LegNumber              INT,
  NumberOfPassengers     INT
);
-- Create Table Locations DDL
CREATE TABLE IF NOT EXISTS streamdb.locations (
  AirportCode VARCHAR(4),
  CountryName VARCHAR(32),
  Region      VARCHAR(16)
);

-- Check count for transactions and locations table
select
  'Transactions' as table_name,
  count(*) as table_count
from
  streamdb.transactions
union
select
  'Locations' as table_name,
  count(*) as table_count
from
  streamdb.locations;

-- Truncate tables
truncate streamdb.transactions;
truncate streamdb.locations;

-- drop tables and database
drop database streamdb cascade;
drop table streamdb.transactions;
drop table streamdb.locations;