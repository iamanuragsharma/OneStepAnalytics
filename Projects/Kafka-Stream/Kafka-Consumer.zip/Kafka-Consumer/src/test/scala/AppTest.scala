import Utils._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, from_json}
import org.scalatest.Assertions._

object AppTest extends App{

  /** Create Spark Session */
  val spark = SparkSession.builder()
    .master("local[*]")
    .appName("Kafka-Consumer-Spark-App-Test")
    .getOrCreate()

  import spark.implicits._

  //TEST 1 - Schema Check for Transactions Records
  /** JSON Data for Transactions Schema */
  val transactionRecord =
    """{"UniqueId":"4224f3c9-323c-e911-a820-a7f2c9e35195","TransactionDateUTC":"2019-03-01 15:00:52.627 UTC","Itinerary":"MUC-CPH-ARN-MUC","OriginAirportCode":"MUC","DestinationAirportCode":"CPH","OneWayOrReturn":"Return","Segment":[{"DepartureAirportCode":"MUC","ArrivalAirportCode":"CPH","SegmentNumber":"1","LegNumber":"1","NumberOfPassengers":"1"},{"DepartureAirportCode":"ARN","ArrivalAirportCode":"MUC","SegmentNumber":"2","LegNumber":"1","NumberOfPassengers":"1"}]}
     {"UniqueId":"5be42e7e-308a-e911-a821-8111ee911e19","TransactionDateUTC":"2019-06-08 21:00:52.843 UTC","Itinerary":"WRO-EIN-WRO","OriginAirportCode":"WRO","DestinationAirportCode":"EIN","OneWayOrReturn":"Return","Segment":[{"DepartureAirportCode":"WRO","ArrivalAirportCode":"EIN","SegmentNumber":"1","LegNumber":"1","NumberOfPassengers":"1"},{"DepartureAirportCode":"EIN","ArrivalAirportCode":"WRO","SegmentNumber":"2","LegNumber":"1","NumberOfPassengers":"1"}]}"""

  /** Create a DF for Spark enforcing the Schema */
  val trxDF= Seq((1, transactionRecord)).toDF("id","value").drop("id")
  val ActualValueTrx = trxDF.select(from_json(col("value"), transactionsSchema).alias("trx")).select("trx.*").drop("Segment")
  /** Create a DF with Data for Spark understanding the Schema from Data*/
  val ExpectedValueTrx=spark.read.json(spark.createDataset(transactionRecord :: Nil)).select(ActualValueTrx.columns.toList.head,ActualValueTrx.columns.toList.tail:_*)

  /** Checking the Match Between */
  assert(ExpectedValueTrx.schema == ActualValueTrx.schema, "Test1: Execution was attempted: It's not a Match between Schema")

/* ******************************************************* */

  // TEST 2 - Schema Check for Locations Records
  /** JSON Data for Locations Schema */
  val locationsRecord = """{"AirportCode":"ZVH","CountryName":"United Arab Emirates","Region":"Asia"}"""
  /** Create a DF for Spark enforcing the Schema */
  val locDF = Seq((1, locationsRecord)).toDF("id", "value").drop("id")
  val ActualValueLoc = locDF.select(from_json(col("value"), locationsSchema).alias("loc")).select("loc.*")
  /** Create a DF with Data for Spark understanding the Schema from Data */
  val ExpectedValueLoc=spark.read.json(spark.createDataset(locationsRecord :: Nil)).select(ActualValueLoc.columns.toList.head, ActualValueLoc.columns.toList.tail: _*)

  /** Checking the Match Between */
  assert(ExpectedValueLoc.schema == ActualValueLoc.schema, "Test1: Execution was attempted: It's not a Match between Schema")

}