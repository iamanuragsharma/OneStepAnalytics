import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{ArrayType, StringType, StructType}

object Utils {
  /**
   * transactionsSchema - Schema Definition for transactions records from Kafka Topic
   */
  val transactionsSchema = new StructType()
    .add("UniqueId", StringType)
    .add("TransactionDateUTC", StringType)
    .add("Itinerary", StringType)
    .add("OriginAirportCode", StringType)
    .add("DestinationAirportCode", StringType)
    .add("OneWayOrReturn", StringType)
    .add("Segment",
      ArrayType(
        new StructType()
          .add("DepartureAirportCode", StringType)
          .add("ArrivalAirportCode", StringType)
          .add("SegmentNumber", StringType)
          .add("LegNumber", StringType)
          .add("NumberOfPassengers", StringType)))

  /**
   * locationsSchema - Schema Definition for locations records from Kafka Topic
   */
  val locationsSchema = new StructType()
    .add("AirportCode", StringType)
    .add("CountryName", StringType)
    .add("Region", StringType)

  /**
   * Sql properties for connection to MySQL DB
   */

  val mySQLjdbcUrl = "jdbc:mysql://localhost:3306/streamdb"
  val dbTableTrx = "transactions"
  val dbTableLoc = "locations"
  val dbUser = "root"
  val dbPassword = "123456"
  val mySqlDriver = "com.mysql.jdbc.Driver"

  /**
   * foreachBatchLoadFunction -> For each batch of records function will load into mySQL DB
   * @param inDF -> input dataframe
   * @param tblName -> table name from database to load
   */
  def foreachBatchLoadFunction(inDF: DataFrame, tblName: String): Unit = {
    Class.forName("com.mysql.jdbc.Driver")
    inDF.write.mode("append")
      .format("jdbc")
      .option("driver", mySqlDriver)
      .option("url", mySQLjdbcUrl)
      .option("dbtable", tblName)
      .option("user", dbUser)
      .option("password", dbPassword)
      .save()
  }

}
