import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{col, explode, from_json}
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.streaming.Trigger
import Utils._

object KafkaConsumerApp extends App {

  /** Create Spark Session */
  val spark = SparkSession.builder()
    .master("local[*]")
    .appName("Kafka-Consumer-Spark-App")
    .getOrCreate()

  /** Create Data Stream from Kafka Topic */
  val dataStream = spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", "localhost:9092")
    .option("subscribe", "channel")
    .option("startingOffsets", "earliest")
    .load()

  /** Reading Data Stream for keys [transactions,locations] from Kafka Topic */
  val transactionsDF = dataStream.where("key='transactions'").selectExpr("CAST(value AS STRING)")
  val locationsDF = dataStream.where("key='locations'").selectExpr("CAST(value AS STRING)")

  /** Enforcing Schema */
  val trxJsonValue = transactionsDF.select(from_json(col("value"), transactionsSchema).alias("trx"))
    .select("trx.*")
  val locJsonValue = locationsDF.select(from_json(col("value"), locationsSchema).alias("loc"))
    .select("loc.*")

  /** Explode Transactions Dataframe to get Segments Columns */
  val trxJsonExplode = trxJsonValue.withColumn("Segments",explode(col("Segment")))

  /** Select Load Ready Transactions Columns */
  val loadReadyTrx = trxJsonExplode.select(
    col("UniqueId"),
    col("TransactionDateUTC"),
    col("Itinerary"),
    col("OriginAirportCode"),
    col("DestinationAirportCode"),
    col("OneWayOrReturn"),
    //col("Segments"),
    col("Segments.DepartureAirportCode").as("DepartureAirportCode"),
    col("Segments.ArrivalAirportCode").as("ArrivalAirportCode"),
    col("Segments.SegmentNumber").cast(IntegerType).as("SegmentNumber"),
    col("Segments.LegNumber").cast(IntegerType).as("LegNumber"),
    col("Segments.NumberOfPassengers").cast(IntegerType).as("NumberOfPassengers")
  )

  /** Select Load Ready Locations Columns */
  val loadReadyLoc = locJsonValue.select(
    col("AirportCode"),
    col("CountryName"),
    col("Region")
  )

  /** Load into MySQL DB */
  val trxQuery = loadReadyTrx.writeStream.trigger(Trigger.Once())
    //.format("console") .option("truncate","false") .outputMode("append")
    .foreachBatch {
      (batchDF: DataFrame, id: Long) => {
        foreachBatchLoadFunction(batchDF, dbTableTrx)
      }
    }
    .start()

  /** Load into MySQL DB */
  val locQuery = loadReadyLoc.writeStream.trigger(Trigger.Once())
    //.format("console") .option("truncate","false") .outputMode("append")
    .foreachBatch {
      (batchDF: DataFrame, id: Long) => {
        foreachBatchLoadFunction(batchDF,dbTableLoc)
      }
    }
    .start()

    /** Stop */
    trxQuery.awaitTermination()
    locQuery.awaitTermination()

// End of Code
}